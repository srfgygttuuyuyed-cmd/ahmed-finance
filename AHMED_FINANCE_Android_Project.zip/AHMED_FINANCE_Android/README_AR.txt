AHMED FINANCE — مشروع أندرويد

هذا المشروع يغلّف نسخة HTML الحالية داخل تطبيق Android باستخدام WebView.
- اسم التطبيق: AHMED FINANCE
- package: com.ahmed.finance
- الحد الأدنى: Android 6.0 (API 23)
- التخزين المحلي: بيانات التطبيق تبقى داخل WebView على الجهاز.
- يحتاج الإنترنت لميزة OCR التي تحمّل Tesseract.js من CDN، أما بقية الواجهة فتعمل محلياً.

إنشاء APK:
1) افتح المجلد AHMED_FINANCE_Android في Android Studio.
2) وافق على تثبيت Android SDK Platform 35 وAndroid Gradle Plugin عند الطلب.
3) من القائمة Build اختر Build Bundle(s) / APK(s) ثم Build APK(s).
4) الملف الناتج غالباً: app/build/outputs/apk/debug/app-debug.apk

ملاحظة:
هذا مشروع Android Studio جاهز للبناء، وليس ملف APK موقّعاً/مبنياً.
بيئة التنفيذ الحالية لا تحتوي Android SDK أو Gradle، لذلك لم يكن ممكناً تجميع APK هنا.
لإصدار نسخة للنشر، أنشئ Signed Bundle/APK من Android Studio.

طريقة بديلة للبناء دون تثبيت Android Studio:
1) أنشئ مستودعاً جديداً على GitHub وارفع محتويات هذا المجلد إليه (وليس ملف ZIP نفسه).
2) افتح تبويب Actions وشغّل Build AHMED FINANCE APK عبر Run workflow، أو انتظر البناء بعد رفع الملفات إلى main.
3) بعد نجاح البناء افتح نتيجة التشغيل ونزّل Artifact باسم AHMED-FINANCE-debug-apk.
4) فك ضغط Artifact لتحصل على app-debug.apk ثم ثبّته على هاتفك. قد تحتاج السماح بالتثبيت من هذا المصدر.
